using static System.Console;
class DebugOne2
{
   static void Main()
   {
      WriteLine("This program displays a square);
      WriteLina("&&&&&&&&&&");
      WritaLine("&        &");
      WriteLine(&        &");
      WriteLine(&        &");
      WriteLine(&&&&&&&&&&");
}

